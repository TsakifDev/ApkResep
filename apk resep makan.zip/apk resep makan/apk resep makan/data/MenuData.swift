//
//  MenuData.swift
//  apk resep makan
//
//  Created by Darwin D jarot on 14/04/21.
//
var MenuData = [
    Makan(id: 0, gambar:"pepes", NamaMenu:"Pepes ayam tahu", sauce: "@byanshakeel",bahan:
            """
Bahan:
- 1 potong tahu putih besar                    .
- 1 butir telur
- 3 siung bawang putih
- 4 butir bawang merah
- satu ruas jahe
- 1/2 sdt garam
- 1/2 sdt gula
- 1 tangkai daun kemangi
- 300 gram ayam giling
- 1 tangkai serai
- 2 lembar daun pisang
""", halus:"""
""", buat:"""
- Hancurkan tahu putih sampai lembut.
- Haluskan bumbu bawang merah, bawang putih, jahe, serai, gula, dan garam menggunakan blender.
- Masukkan bumbu yang sudah diblender ke tahu kemudian tambahkan ayam giling dan telur.
- Tambahkan daun kemangi, kemudian aduk hingga rata.
- Bakar daun pisang di atas teflon sebentar saja agar daun tidak mudah pecah saat untuk membungkus.
- Bungkus adonan pepes dengan daun pisang.
- Tutup ujungnya dengan tusuk gigi.
- Kukus pepes selama kurang lebih 30 menit, angkat.
- Bakar pepes di atas teflon sampai rata.
- Angkat dan sajikan.
"""),
    
    Makan(id: 1, gambar:"padang", NamaMenu:"Udang saos padang", sauce: "@literasihalal", bahan:
            """
Bahan:
- 300 gram udang segar, potong sungutnya,
- 1/2 buah bawang bombai, potong kasar
- 1 buah tomat, potong kasar
- 1 sdm kecap manis
- 1 sdt saus tiram
- 3 sdm saus tomat
- 2 lembar daun jeruk
- Garam, gula dan lada bubuk secukupnya.
""", halus:"""
- 4 butir bawang merah
- 2 siung bawang putih
- 1 buah cabai merah
- 1 cm jahe
- 5 cabai keriting
""", buat:"""
- Didihkan air, beri sedikit garam, rebus udang sampai berubah warna, angkat, tiriskan.
- Tumis bumbu halus sampai wangi, masukkan daun jeruk, bawang bombai, dan tomat, aduk sampai layu.
- Kemudian tambahkan saus tomat, saus tiram, kecap manis, garam, gula, dan lada bubuk, aduk rata.
- Tuangi sedikit air, aduk rata dan biarkan mendidih.
- Lalu masukkan udang, masak sambil diaduk sampai bumbu meresap.
- Koreksi rasa bila sudah pas angkat dan sajikan segera.
"""),
    
    Makan(id: 2, gambar:"potato", NamaMenu:"Potato wedges", sauce: "@resepmasakan1001", bahan:
            """
Bahan:
- 5 buah kentang ukuran besar, potong-potong
- 100 ml susu cair
- 1 butir telur
- Tepung terigu secukupnya
- Garam, merica, bubuk kaldu secukupnya
- 1,5 sdt bubuk paprika
- 1,5 sdt bubuk bawang putih
- Parsley kering buat taburan kalau suka
""", halus:"", buat:"""
Cara membuat:
- Campurkan telur dan susu, aduk hingga rata. Sisihkan.
- Campurkan tepung terigu, garam, merica, bubuk kaldu, bubuk paprika, dan bubuk bawang putih. Sisihkan.
- Celupkan beberapa kentang ke dalam campuran susu dan telur.
- Lalu masukkan ke dalam adonan tepung.
- Panaskan minyak goreng, lalu goreng kentang hingga matang.
- Angkat, taburi parsley kering, sajikan.
"""),
    
    Makan(id: 3, gambar:"siaomai", NamaMenu:"Siomay ikan tengiri", sauce: "@febrianaannisah", bahan:
            """
Bahan:
- 320 gr filet ikan tenggiri
- 30 gr lemak ayam
- 120 gr tepung sagu
- 3 butir telur
- 1/2 buah labu siam ukuran kecil, kukus kemudian haluskan
- 2 batang daun bawang, iris halus
- 4 buah bawang putih cincang halus, goreng
- 1 sdm saus tiram
- 2 sdm kecap ikan
- 1 sdm kecap asin
- 2 sdm minyak wijen
- 2 sdm minyak bawang putih
- 1 sdm garam
- 2 sdt gula pasir
- 1/2 sdt kaldu ayam bubuk
- 1 sdm merica bubuk
""", halus:"""
Bahan pelengkap:
- Kulit pangsit
- Tahu putih, potong segi tiga
- Kentang rebus
- Pare, potong buang biji
- Kol/kubis
""", buat:"""
Cara membuat:
- Masukkan semua bahan (kecuali tepung sagu dan irisan daun bawang) ke foodprocessor, campur sampai adonan menjadi pasta, matikan.
- Masukkan tepung sagu, campur lagi sampai rata.
- Pindahkan adonan siomay ke wadah, masukkan irisan daun bawang, aduk rata.
- Isikan adonan siomay ke bahan pelengkap,kulit pangsit, tahu putih, kentang, dan pare.
- Garis-garis menggunakan garpu. Panaskan kukusan, kukus selama 15 menit atau sampai siomay matang.
- Siomay siap disajikan dengan sambal kacang.
"""),
    
    Makan(id: 4, gambar:"ikan", NamaMenu:"Ikan kuah asam", sauce: "@elizasetiawan", bahan:
            """
Bahan:
- 500 gr ikan
- 1 liter air
- 1 buah jeruk nipis
- 2 batang serai, memarkan
- 4 lembar daun jeruk, buang tulangnya
- 2 cm jahe, memarkan
- 8 buah belimbing wuluh, iris-iris
- 1 buah tomat, potong-potong
- 4 cabai keriting, iris-iris
- 3 cabai rawit merah, iris-iris
- Daun kemangi secukupnya
- Garam, gula  secukupnya
""", halus:"""
Bumbu halus:
- 3 siung bawang putih
- 6 bawang merah
- 2 cm kunyit bakar
""", buat:"""
Cara membuat:
- Bersihkan ikan, potong sesuai selera dan lumuri jeruk nipis. Diamkan 10 menit, bilas.
- Masak air sampai mendidih.
- Tumis bumbu halus, serai, jahe, cabai dan daun jeruk sampai harum.
- Masukkan ke kuah mendidih, beri garam dan sedikit gula.
- Masukkan ikan, dan masak hingga matang dan bumbu meresap.
- Masukkan irisan tomat, belimbing wuluh dan daun kemangi.
- Tes rasa dan matikan api. Ikan kuah asam siap disantap.
"""),
    
    Makan(id: 5, gambar:"sup", NamaMenu:"Sup ayam", sauce: "@resepmakananspesial", bahan:
            """
Bahan:
- 1 ekor ayam potong 12 bagian
- 1 pack kembang tahu
- 2 buah wortel,
- 1 buah kentang
- Lada, penyedap jamur, bubuk pala secukupnya
- 3 siung bawang putih, cincang
- 5 siung bawang merah, iris tipis
- 2 cm jahe, geprek
- Bawang goreng secukupnya
""", halus:"", buat:"""
Cara membuat:
- Rebus air sampai mendidih baru masukkan daging ayam, rebus sebentar kemudian buang airnya agar kotoran dan lemaknya hilang.
- Rebus kembali, masukkan daging kembali masak sampai mulai empuk, masukkan wortel dan kentang.
- Tumis bawang putih, bawang merah, dan jahe hingga harum.
- Masukkan bumbu ke rebusan daging, aduk-aduk hingga rata, tambahkan penyedap, lada bubuk lada.
- Masak sampai wortel dan kentang empuk.
- Tes rasa, tambahkan daun bawang dan bawang goreng.
- Angkat dan sajikan.
"""),
    
    Makan(id: 6, gambar:"telor", NamaMenu:"Orak arik telur", sauce: "@dapur.pandamerah",bahan:
            """
Bahan:
- 2 buah telur
- 100 gr jamur, potong-potong
- 1/2 paprika hijau, potong dadu
- 1/2 paprika merah, potong dadu
- Garam dan merica secukupnya
""", halus:"", buat:"""
Cara membuat:
- Tumis jamur hingga matang, masukkan paprika. Tumis sebentar.
- Kemudain kocok telur yang sudah dibumbui dengan garam dan merica, tuang ke tumisan jamur dan paprika.
- Aduk terus hingga telur matang, tapi jangan terlalu lama memasak telur agar teksturnya tidak terlalu kering.
- Orak arik telur siap dihidangkan.
"""),
    
    
    Makan(id: 7, gambar:"tim", NamaMenu:"Tim salmon", sauce: "@cicie_kitchen",bahan:
            """
Bahan:
- 250 gr salmon fillet
- 5 bwg putih, iris tipis
- 3 lembar daun seledri
- seruas tipis jahe, potong tipis
- 1 batang serai, ambil putihnya, potong-potong
- 1 sdt minyak wijen
- 1 sdt minyak ikan
- 1 sdm kecap asin
- 1 jeruk nipis
- Air 200 ml
""", halus:"", buat:"""
Cara membuat:
- Cuci salmon, beri perasan jeruk nipis, diamkan 5 menit.
- Siapkan wadah anti panas, taruh ikan lalu taburi bawang putih, irisan daun bawang jahe, dan serai.
- Masukkan air, cek rasa.
- Panaskan alat steam, lalu taruh mangkuk isi salmon, steam selama 30 menit atau sampai matang.
"""),
    
    
    Makan(id: 8, gambar:"tumis", NamaMenu:"Tumis tahu jamur", sauce: "@tiaswidodo",bahan:
            """
Bahan:
- 1/4 buah tahu putih potong sesuai selera
- 300 gr jamur tiram suir-suir besar
- 5 lembar jamur kuping potong-potong
- 1 buah cabai merah buang isi potong-potong
- 1 buah tomat potong-potong
- 8 buah cabai rawit potong-potong
- 3 siung bawang putih iris tipis
- 1 siung bawang merah iris tipis
""", halus:"", buat:"""
Cara memasak:
- Tumis bawang dan cabai sampai harum dan layu masukkan tomat dan tahu.
- Diamkan sebentar jangan dibolak balik agra tahu berubah warna
- Setelah tahu berubah warna, masukkan jamur, tambahkan sedikit air.
- Kemudian tambahkan gula, garam, kaldu ayam bubuk, lada, saus sambal, saus tiram, masak sampai matang.
- Tes rasa dan sajikan.
"""),
    
    
    Makan(id: 9, gambar:"hijau", NamaMenu:"Bubur kacang hijau", sauce: "@resep_kueterbaru",bahan:
            """
Bahan:
Bahan:
- 250 gr kacang hijau
- 2 liter air
- 2 lembar daun pandan, simpulkan
- 200 gr gula pasir
- 1/2 sdt garam
- 200 ml santan kental, didihkan sambil diaduk perlahan supaya tidak pecah
""", halus:"", buat:"""
Cara membuat:
- Cuci bersih kacang hijau terlebih dahulu, lalu rendam semalaman.
- Esok harinya buang air rendaman, cuci bersih sekali lagi, tiriskan.
- Rebus kacang hijau sampai empuk dan diberi daun pandan.
- Masak sampai air berkurang banyak dan sebagian kacang hijau merekah.
- Tambahkan garam dan gula pasir, aduk sampai gula larut. Angkat.
- Didihkan santan, tambahkan sedikit garam sambil diaduk perlahan supaya tidak pecah. Angkat.
- Sajikan bubur kacang hijau dengan diberi santan di atasnya.
"""),
    
]
