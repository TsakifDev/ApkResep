//
//  MenuMakanan.swift
//  apk resep makan
//
//  Created by Darwin D jarot on 13/04/21.
//
import SwiftUI

struct MenuMakanan: View {
    var body: some View {
        ZStack{
            TabView{
                Resep()
                    .tabItem{
                        Image(systemName: "house.fill")
                        Text("Beranda")
                    }
                propil()
                    .tabItem{
                        Image(systemName: "person.circle.fill")
                        Text("Profil")
                    }
            }
        }
    }
}
        struct zig_Previews: PreviewProvider {
            static var previews: some View {
                MenuMakanan()
                    .preferredColorScheme(.dark)
            }
        }
struct Resep: View {
    var body: some View {
        NavigationView{
        List(MenuData){Data in
        NavigationLink(
            destination: DetailMenu(MakanBang : Data)){
        ZStack {
            HStack{
            VStack (alignment: .leading) {
                        VStack (alignment: .leading) {
                            Image(Data.gambar)
                                .resizable()
                                .frame(width: 310, height: 200)
                                .cornerRadius(12)
                            
                            Text(Data.NamaMenu)
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.yellow)
                                .padding(.leading, 12)
                            Text(Data.sauce)
                                .foregroundColor(.secondary)
                                .font(.subheadline)
                                .padding(.leading, 12)
                        }.frame(width: 320, height: 260)
                        .background(Color.gray.opacity(0.3))
                        .cornerRadius(12)
            }
                    
                }
            Image(systemName: "arrow.right.circle.fill")
                .foregroundColor(.yellow)
                .font(.system(size: 30))
                .padding(.top,200)
                .padding(.leading,250)
            
            }.padding(11)
        .navigationTitle(Text("Makanan Berprotein"))
        .navigationBarItems(leading: Image(systemName: "hare.fill")
        .font(.system(size: 30)).foregroundColor(.yellow))
            }
      
        }
        
        
    }
}
}

    
