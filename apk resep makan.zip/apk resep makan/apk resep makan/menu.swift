//
//  menu.swift
//  apk resep makan
//
//  Created by Darwin D jarot on 14/04/21.
//
struct Booking {
    let id : Int
    let image : String
    let namaHotel : String
    let Lokasi : String
    let rating : Int
    let harga : Int
    let detailHotel : String
}
