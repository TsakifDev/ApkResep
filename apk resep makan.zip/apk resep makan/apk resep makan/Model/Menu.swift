//
//  Menu.swift
//  apk resep makan
//
//  Created by Darwin D jarot on 14/04/21.
//
struct Makan : Identifiable {
    let id : Int
    let gambar : String
    let NamaMenu : String
    let sauce : String
    let bahan : String
    let halus : String
    let buat : String
    
    
}
