//
//  DetailMenu.swift
//  apk resep makan
//
//  Created by Darwin D jarot on 15/04/21.
//

import SwiftUI

struct DetailMenu: View {
    
    let MakanBang : Makan
    
    var body: some View {
        ZStack{
        VStack (alignment: .leading) {
            Image(MakanBang.gambar)
                .resizable()
                .frame(width: 350, height: 220)
                .cornerRadius(12)
            
            Text(MakanBang.NamaMenu)
                .font(.title3)
                .fontWeight(.semibold)
                .foregroundColor(.yellow)
                .padding(.leading, 12)
            Text(MakanBang.sauce)
                .foregroundColor(.secondary)
                .font(.subheadline)
                .padding(.leading, 12)
             
        }.frame(width: 342, height: 285)
        .background(Color.gray.opacity(0.3))
        .cornerRadius(15)
        }
    
        ScrollView{
            VStack (alignment: .leading) {
                Text(MakanBang.bahan)
                    .multilineTextAlignment(.leading)
                .frame(width: 330.0)
                .padding(.bottom, 10)
                Text(MakanBang.halus)
                .padding(.bottom, 10)

                Text(MakanBang.buat)

            }
        }
            
    }
}

struct DetailMenu_Previews: PreviewProvider {
    static var previews: some View {
        DetailMenu(MakanBang: Makan(id: 0, gambar:"", NamaMenu:"", sauce: "", bahan:"", halus:"", buat:""))
            .preferredColorScheme(.dark)
    }
}
