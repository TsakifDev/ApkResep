//
//  profile.swift
//  apk resep makan
//
//  Created by Darwin D jarot on 16/04/21.
//

import SwiftUI

struct profile: View {
    var body: some View {
        ZStack{
            TabView{
                Resep()
                    .tabItem{
                        Image(systemName: "house.fill")
                        Text("Beranda")
                    }
                propil()
                    .tabItem{
                        Image(systemName: "person.circle.fill")
                        Text("Profil")
                    }
            }
        }
    }
}

struct profile_Previews: PreviewProvider {
    static var previews: some View {
        profile()
            .preferredColorScheme(.dark)
    }
}

struct propil: View {
    var body: some View {
        VStack {
            HStack {
                Spacer()
                
                VStack {
                    Image("led")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: 200, height: 200)
                        .clipShape(Circle())
                        .padding(.top, 44)
                    
                    Text("Darwin D Jarot")
                        .font(.system(size: 20))
                        .bold()
                        .foregroundColor(.yellow)
                        .padding(.top, 12)
                    
                    Text("@DarwinD")
                        .font(.system(size: 18))
                        .foregroundColor(.secondary)
                        .padding(.top, 4)
                }
                Spacer()
            }
        }
        
    }
}
